package com.parksmart.parking.controller;

import com.parksmart.parking.entity.ParkingLot;
import com.parksmart.parking.service.ParkingLotService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/parking-lots")
@CrossOrigin(origins = "*")
public class ParkingLotController {

    private final ParkingLotService parkingLotService;

    public ParkingLotController(ParkingLotService parkingLotService) {
        this.parkingLotService = parkingLotService;
    }

    @GetMapping
    public List<ParkingLot> getAllParkingLots() {
        return parkingLotService.getAllParkingLots();
    }

    @GetMapping("/{id}")
    public ParkingLot getParkingLotById(@PathVariable Long id) {
        return parkingLotService.getParkingLotById(id);
    }

    @PostMapping
    public ParkingLot createParkingLot(@RequestBody ParkingLot parkingLot) {
        return parkingLotService.createParkingLot(parkingLot);
    }

    @PutMapping("/{id}")
    public ParkingLot updateParkingLot(
            @PathVariable Long id,
            @RequestBody ParkingLot parkingLot) {

        return parkingLotService.updateParkingLot(id, parkingLot);
    }

    @DeleteMapping("/{id}")
    public String deleteParkingLot(@PathVariable Long id) {
        parkingLotService.deleteParkingLot(id);
        return "Parking lot deleted successfully";
    }
}
