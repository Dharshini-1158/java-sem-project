package com.parksmart.parking.repository;

import com.parksmart.parking.entity.CheckInOut;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CheckInOutRepository extends JpaRepository<CheckInOut, Long> {
}
