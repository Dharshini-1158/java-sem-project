package com.parksmart.parking.controller;

import com.parksmart.parking.entity.Slot;
import com.parksmart.parking.service.SlotService;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/slots")
@CrossOrigin(origins = "*")
public class SlotController {

    private final SlotService slotService;

    public SlotController(SlotService slotService) {
        this.slotService = slotService;
    }

    @GetMapping
    public List<Slot> getAllSlots() {
        return slotService.getAllSlots();
    }

    @GetMapping("/{id}")
    public Slot getSlotById(@PathVariable Long id) {
        return slotService.getSlotById(id);
    }

    @GetMapping("/parking-lot/{parkingLotId}")
    public List<Slot> getSlotsByParkingLot(
            @PathVariable Long parkingLotId) {

        return slotService.getSlotsByParkingLot(parkingLotId);
    }

    // Get available slots for selected time window
    @GetMapping("/available/{parkingLotId}")
    public List<Slot> getAvailableSlots(
            @PathVariable Long parkingLotId,
            @RequestParam LocalDateTime startTime,
            @RequestParam LocalDateTime endTime) {

        return slotService.getAvailableSlots(
                parkingLotId,
                startTime,
                endTime
        );
    }

    // Get real-time parking lot occupancy
    @GetMapping("/occupancy/{parkingLotId}")
    public Map<String, Object> getOccupancy(
            @PathVariable Long parkingLotId) {

        return slotService.getOccupancy(parkingLotId);
    }

    @PostMapping
    public Slot createSlot(@RequestBody Slot slot) {
        return slotService.createSlot(slot);
    }

    @PutMapping("/{id}")
    public Slot updateSlot(
            @PathVariable Long id,
            @RequestBody Slot slot) {

        return slotService.updateSlot(id, slot);
    }

    @DeleteMapping("/{id}")
    public String deleteSlot(@PathVariable Long id) {
        slotService.deleteSlot(id);
        return "Slot deleted successfully";
    }
}