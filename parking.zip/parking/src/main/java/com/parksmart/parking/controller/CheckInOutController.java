package com.parksmart.parking.controller;

import com.parksmart.parking.entity.CheckInOut;
import com.parksmart.parking.service.CheckInOutService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/check-in-out")
@CrossOrigin(origins = "*")
public class CheckInOutController {

    private final CheckInOutService checkInOutService;

    public CheckInOutController(CheckInOutService checkInOutService) {
        this.checkInOutService = checkInOutService;
    }

    @GetMapping
    public List<CheckInOut> getAllCheckInOut() {
        return checkInOutService.getAllCheckInOut();
    }

    @PostMapping("/check-in/{bookingId}")
    public CheckInOut checkIn(@PathVariable Long bookingId) {
        return checkInOutService.checkIn(bookingId);
    }

    @PostMapping("/check-out/{bookingId}")
    public Object checkOut(@PathVariable Long bookingId) {
        try {
            return checkInOutService.checkOut(bookingId);
        } catch (Exception e) {
            return "ERROR: " + e.getMessage();
        }
    }
}