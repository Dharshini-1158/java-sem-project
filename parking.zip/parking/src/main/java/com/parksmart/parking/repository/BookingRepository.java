package com.parksmart.parking.repository;

import com.parksmart.parking.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {

    List<Booking> findBySlotIdAndStatusInAndStartTimeLessThanAndEndTimeGreaterThan(
            Long slotId,
            List<String> statuses,
            LocalDateTime endTime,
            LocalDateTime startTime
    );
}
