package com.parksmart.parking.service;

import com.parksmart.parking.entity.Booking;
import com.parksmart.parking.entity.CheckInOut;
import com.parksmart.parking.repository.BookingRepository;
import com.parksmart.parking.repository.CheckInOutRepository;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class CheckInOutService {

    private final CheckInOutRepository checkInOutRepository;
    private final BookingRepository bookingRepository;

    // ₹50 for every started extra hour
    private static final double PENALTY_PER_HOUR = 50.0;

    public CheckInOutService(
            CheckInOutRepository checkInOutRepository,
            BookingRepository bookingRepository) {

        this.checkInOutRepository = checkInOutRepository;
        this.bookingRepository = bookingRepository;
    }

    public List<CheckInOut> getAllCheckInOut() {
        return checkInOutRepository.findAll();
    }

    public CheckInOut checkIn(Long bookingId) {

        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        CheckInOut checkInOut = new CheckInOut();

        checkInOut.setBooking(booking);
        checkInOut.setCheckInTime(LocalDateTime.now());
        checkInOut.setPenalty(0);

        booking.setStatus("CHECKED_IN");
        bookingRepository.save(booking);

        return checkInOutRepository.save(checkInOut);
    }

    public CheckInOut checkOut(Long bookingId) {

        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        CheckInOut checkInOut = checkInOutRepository.findAll()
                .stream()
                .filter(c -> c.getBooking() != null)
                .filter(c -> c.getBooking().getId().equals(bookingId))
                .filter(c -> c.getCheckOutTime() == null)
                .findFirst()
                .orElseThrow(() ->
                        new RuntimeException("Active check-in not found for booking " + bookingId));

        LocalDateTime checkOutTime = LocalDateTime.now();

        checkInOut.setCheckOutTime(checkOutTime);

        // Overstay penalty calculation
        if (booking.getEndTime() != null
                && checkOutTime.isAfter(booking.getEndTime())) {

            long extraMinutes = Duration.between(
                    booking.getEndTime(),
                    checkOutTime
            ).toMinutes();

            long extraHours = (long) Math.ceil(extraMinutes / 60.0);

            double penalty = extraHours * PENALTY_PER_HOUR;

            checkInOut.setPenalty(penalty);

        } else {
            checkInOut.setPenalty(0);
        }

        booking.setStatus("COMPLETED");
        bookingRepository.save(booking);

        return checkInOutRepository.save(checkInOut);
    }
}
