package com.parksmart.parking.service;

import com.parksmart.parking.entity.Booking;
import com.parksmart.parking.repository.BookingRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class BookingService {

    private final BookingRepository bookingRepository;

    public BookingService(BookingRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }

    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public Booking getBookingById(Long id) {
        return bookingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Booking not found"));
    }

    public Booking createBooking(Booking booking) {

        if (booking.getStartTime() == null || booking.getEndTime() == null) {
            throw new RuntimeException("Start time and end time are required");
        }

        if (!booking.getStartTime().isBefore(booking.getEndTime())) {
            throw new RuntimeException("Start time must be before end time");
        }

        List<Booking> bookings = bookingRepository.findAll();

        for (Booking existingBooking : bookings) {

            // Only active bookings should block the slot
            if (!"BOOKED".equals(existingBooking.getStatus())
                    && !"CHECKED_IN".equals(existingBooking.getStatus())) {
                continue;
            }

            if (existingBooking.getSlot() != null
                    && booking.getSlot() != null
                    && existingBooking.getSlot().getId()
                    .equals(booking.getSlot().getId())) {

                LocalDateTime existingStart =
                        existingBooking.getStartTime();

                LocalDateTime existingEnd =
                        existingBooking.getEndTime();

                boolean overlapping =
                        booking.getStartTime().isBefore(existingEnd)
                                && booking.getEndTime().isAfter(existingStart);

                if (overlapping) {
                    throw new RuntimeException(
                            "This slot is already booked for the selected time"
                    );
                }
            }
        }

        booking.setStatus("BOOKED");

        return bookingRepository.save(booking);
    }

    public Booking updateBooking(Long id, Booking booking) {

        Booking existingBooking = getBookingById(id);

        existingBooking.setVehicleNumber(booking.getVehicleNumber());
        existingBooking.setStartTime(booking.getStartTime());
        existingBooking.setEndTime(booking.getEndTime());
        existingBooking.setSlot(booking.getSlot());
        existingBooking.setStatus(booking.getStatus());

        return bookingRepository.save(existingBooking);
    }

    public void deleteBooking(Long id) {
        bookingRepository.deleteById(id);
    }
}