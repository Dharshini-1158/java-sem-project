package com.parksmart.parking.service;

import com.parksmart.parking.entity.Slot;
import com.parksmart.parking.repository.BookingRepository;
import com.parksmart.parking.repository.CheckInOutRepository;
import com.parksmart.parking.repository.SlotRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class SlotService {

    private final SlotRepository slotRepository;
    private final BookingRepository bookingRepository;
    private final CheckInOutRepository checkInOutRepository;

    public SlotService(
            SlotRepository slotRepository,
            BookingRepository bookingRepository,
            CheckInOutRepository checkInOutRepository) {

        this.slotRepository = slotRepository;
        this.bookingRepository = bookingRepository;
        this.checkInOutRepository = checkInOutRepository;
    }

    public List<Slot> getAllSlots() {
        return slotRepository.findAll();
    }

    public Slot getSlotById(Long id) {
        return slotRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Slot not found"));
    }

    public Slot createSlot(Slot slot) {
        return slotRepository.save(slot);
    }

    public Slot updateSlot(Long id, Slot slot) {

        Slot existingSlot = getSlotById(id);

        existingSlot.setSlotNumber(slot.getSlotNumber());
        existingSlot.setStatus(slot.getStatus());
        existingSlot.setParkingLot(slot.getParkingLot());

        return slotRepository.save(existingSlot);
    }

    public void deleteSlot(Long id) {
        slotRepository.deleteById(id);
    }

    public List<Slot> getSlotsByParkingLot(Long parkingLotId) {
        return slotRepository.findByParkingLotId(parkingLotId);
    }

    // Get available slots for selected time window
    public List<Slot> getAvailableSlots(
            Long parkingLotId,
            LocalDateTime startTime,
            LocalDateTime endTime) {

        if (!startTime.isBefore(endTime)) {
            throw new RuntimeException(
                    "Start time must be before end time"
            );
        }

        List<Slot> slots =
                slotRepository.findByParkingLotId(parkingLotId);

        List<String> activeStatuses = List.of(
                "BOOKED",
                "CHECKED_IN"
        );

        return slots.stream()
                .filter(slot -> {

                    List<?> overlappingBookings =
                            bookingRepository
                                    .findBySlotIdAndStatusInAndStartTimeLessThanAndEndTimeGreaterThan(
                                            slot.getId(),
                                            activeStatuses,
                                            endTime,
                                            startTime
                                    );

                    return overlappingBookings.isEmpty();
                })
                .collect(Collectors.toList());
    }

    // Get real-time parking lot occupancy
    public Map<String, Object> getOccupancy(Long parkingLotId) {

        List<Slot> slots =
                slotRepository.findByParkingLotId(parkingLotId);

        int totalSlots = slots.size();

        long occupiedSlots = checkInOutRepository.findAll()
                .stream()
                .filter(checkInOut ->
                        checkInOut.getCheckOutTime() == null)
                .filter(checkInOut ->
                        checkInOut.getBooking() != null)
                .filter(checkInOut ->
                        checkInOut.getBooking().getSlot() != null)
                .filter(checkInOut ->
                        checkInOut.getBooking()
                                .getSlot()
                                .getParkingLot()
                                .getId()
                                .equals(parkingLotId))
                .count();

        int availableSlots =
                totalSlots - (int) occupiedSlots;

        double occupancyPercentage =
                totalSlots == 0
                        ? 0
                        : ((double) occupiedSlots / totalSlots) * 100;

        Map<String, Object> result = new HashMap<>();

        result.put("totalSlots", totalSlots);
        result.put("occupiedSlots", occupiedSlots);
        result.put("availableSlots", availableSlots);
        result.put("occupancyPercentage", occupancyPercentage);

        return result;
    }
}